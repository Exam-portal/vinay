package com.dao;

public @interface service {

}

package com.dao;

import java.util.List;

import org.aspectj.weaver.patterns.TypePatternQuestions.Question;

public interface Questiondao {
	
	public static void addQuestion(Question question) {
	Questiondao.addQuestion(question);
}
	public default QuestionBank findQuestion(int id) {
		return (QuestionBank) Questiondao.findAllQuestion();
	}
	public static List<Question> findAllQuestion(){
		return Questiondao.findAllQuestion();
	}
	public static  boolean updateQuestion(Question question) {
		return Questiondao.updateQuestion(question);
	}
	public static  boolean deleteQuestion(Question question) {
		return Questiondao.deleteQuestion(question);
	}
	

}

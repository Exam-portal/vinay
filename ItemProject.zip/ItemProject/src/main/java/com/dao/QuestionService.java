package com.dao;

import java.util.List;

@service
public class QuestionService {

	Questiondao QuestiondaoImpl;
	
	public void add(QuestionBank question) {
		Questiondao.addQuestion(question);
	}
	public QuestionBank find(int id) {
		return Questiondao.findQuestion(id);
		
	}
}

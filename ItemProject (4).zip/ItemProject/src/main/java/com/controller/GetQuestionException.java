package com.controller;

public class GetQuestionException extends RuntimeException {

	public GetQuestionException() {
		super("question cannot be changed successfully");
	}
	public String toString() {
		return "question cannot be changed kindly remove one question";
	}
}

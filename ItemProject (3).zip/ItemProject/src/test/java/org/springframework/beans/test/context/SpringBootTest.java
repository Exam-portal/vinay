package org.springframework.beans.test.context;

public @interface SpringBootTest {

}

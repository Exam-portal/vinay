package com.controller;

public class AddQuestionException  extends RuntimeException{
 
	public AddQuestionException() {
		super("question cannot be changed successfully");
	}
	public String toString() {
		return "question cannot be changed kindly remove one question";
		
	}
}

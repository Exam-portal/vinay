package com.dao;

import java.util.List;

import org.aspectj.weaver.patterns.TypePatternQuestions.Question;

public interface QuestionService {
	
	public static void addQuestion(Question question) {
	QuestionService.addQuestion(question);
}
	public static Question validateQuestion(int id) {
		return (Question) QuestionService.validateQuestion(id);
	}
	
	public static List<Question> findAllQuestion (int questionId){
		return QuestionService.findAllQuestion( questionId);
	}
	public static  boolean updateQuestion(Question question) {
		return QuestionService.updateQuestion(question);
	}
	public static Object findAllQuestion() {
		// TODO Auto-generated method stub
		return null;
	}
	public static  boolean deleteQuestion(Question question) {
		return QuestionService.deleteQuestion(question);
	}
	public List<Question> findAllQuestions(int questionId);
	public void add(Question question);
	public List<Question> findAllQuestions1(Question_mgn question);
	public Object Add(Question_mgn question);
	public void addQuestion(int i);
	
	

}
			
	


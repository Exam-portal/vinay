package org.springframework.sterotype;

public class Repository {

}
